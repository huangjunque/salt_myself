
patch  -p1 -i nginx-http-reqstat/nginx_filter.patch 
patch  -p1 -i nginx-http-reqstat/connection.patch

yum -y install pcre-devel openssl openssl-devel

./configure --prefix=/Users/zealot/github/bin/nginx1.6.2  --add-module=./nginx-http-reqstat/  --with-http_ssl_mod
ule --with-cc-opt="-Wno-deprecated-declarations -Wunused-variable"
