<?php

  class gtMissingArgumentException extends RuntimeException
  {
  }

?>
